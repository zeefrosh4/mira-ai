package com.mira.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("mira", MODE_PRIVATE)
        val pad = (18 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })

        fun text(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            this.text = t; textSize = size; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, pad / 3, 0, pad / 3); root.addView(this)
        }
        fun field(hint: String, key: String, def: String = "") = EditText(this).apply {
            this.hint = hint; setText(p.getString(key, def)); setSingleLine(); root.addView(this)
        }
        fun button(label: String, click: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { click() }
            root.addView(this, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        text("MIRA AI", 28f, true)
        text("Say \"Mira\" and then your command. Example: \"Mira, open WhatsApp Business\". No tapping needed once MIRA is started.", 15f)
        val key = field("Gemini API key", "key")
        val model = field("Model", "model", "gemini-2.5-flash")
        val city = field("Your city (for weather)", "city")
        val cc = field("Country code, digits only (for numbers starting with 0)", "cc")

        fun save() = p.edit().putString("key", key.text.toString().trim())
            .putString("model", model.text.toString().trim().ifEmpty { "gemini-2.5-flash" })
            .putString("city", city.text.toString().trim())
            .putString("cc", cc.text.toString().filter { it.isDigit() }).apply()

        button("1. Allow permissions") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        button("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("3. Start MIRA") {
            save()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Allow permissions first (step 1)", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, MiraService::class.java))
                Toast.makeText(this, "MIRA is listening. Say \"Mira\".", Toast.LENGTH_LONG).show()
            }
        }
        button("Stop MIRA") { stopService(Intent(this, MiraService::class.java)) }
    }
}
