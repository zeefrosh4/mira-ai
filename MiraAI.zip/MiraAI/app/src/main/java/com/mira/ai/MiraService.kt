package com.mira.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.Locale

class MiraService : Service(), TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var awaiting = false
    private var running = true
    private val history = JSONArray()
    private val prefs by lazy { getSharedPreferences("mira", MODE_PRIVATE) }
    private val wake = Regex("\\b(mira|myra|meera)\\b[,.!?]?\\s*")

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("mira", "MIRA", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "mira").setContentTitle("MIRA is listening")
            .setContentText("Say \"Mira\" followed by a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.language = Locale.getDefault()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { done() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { done() }
        })
        main.post { listen() }
    }

    private fun done() { speaking = false; main.post { listen() } }

    private fun say(t: String) {
        speaking = true
        recognizer?.cancel()
        if (!ttsReady) { done(); return }
        tts?.speak(t.replace(Regex("[*_#`>]"), "").replace(Regex("https?://\\S+"), "link"), TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        if (!running || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: android.os.Bundle?) {}
                override fun onEvent(t: Int, p: android.os.Bundle?) {}
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) awaiting = false
                    main.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 300)
                }
                override fun onResults(b: android.os.Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank() || !handle(t)) main.postDelayed({ listen() }, 200)
                }
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()))
        }
    }

    /** Returns true when MIRA is going to speak (so listening restarts after speech). */
    private fun handle(raw: String): Boolean {
        val t = raw.lowercase(Locale.getDefault()).trim()
        val cmd: String
        if (awaiting) { awaiting = false; cmd = t }
        else {
            val m = wake.find(t) ?: return false
            cmd = t.substring(m.range.last + 1).trim()
            if (cmd.isEmpty()) { awaiting = true; say("Yes?"); return true }
        }
        run(cmd)
        return true
    }

    private fun run(cmd: String) {
        if (route(cmd)) return
        speaking = true
        Thread { val a = ask(cmd); main.post { say(a) } }.start()
    }

    private fun route(c: String): Boolean {
        val t = c.trim().trimEnd('.', '!', '?')
        Regex("^(stop|cancel|never mind|nevermind)$").find(t)?.let { say("Okay."); return true }
        Regex("^(?:open|launch|start)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(t)?.let { openApp(it.groupValues[1]); return true }
        Regex("^call\\s+(.+)$").find(t)?.let { call(it.groupValues[1]); return true }
        Regex("^(?:send\\s+)?(?:a\\s+)?(whatsapp business|whatsapp|sms|text|message)\\s+(?:to\\s+)?(.+?)\\s+(?:saying|that says|say that|say)\\s+(.+)$")
            .find(t)?.let { sendMessage(it.groupValues[1], it.groupValues[2], it.groupValues[3]); return true }
        Regex("^(?:play|search youtube for)\\s+(.+?)(?:\\s+on youtube)?$").find(t)?.let {
            if (t.contains("youtube") || t.startsWith("play ")) {
                go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1]))))
                say("Searching YouTube."); return true
            }
        }
        return false
    }

    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { startActivity(i) } catch (e: Exception) { say("I could not open that.") } }

    private fun openApp(name: String) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }
        val n = if (name == "twitter") "x" else name
        val hit = apps.firstOrNull { it.first == n } ?: apps.filter { it.first.contains(n) }.minByOrNull { it.first.length }
        val intent = hit?.let { pm.getLaunchIntentForPackage(it.second) }
        if (intent == null) { say("I could not find $name on this phone."); return }
        go(intent); say("Opening $name.")
    }

    private fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun number(spec: String): String? {
        val digits = spec.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 7) return digits
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return null
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$spec%"), null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun intl(n: String): String {
        val d = n.filter { it.isDigit() }
        val cc = prefs.getString("cc", "") ?: ""
        return if (!n.trim().startsWith("+") && d.startsWith("0") && cc.isNotEmpty()) cc + d.drop(1) else d
    }

    private fun call(spec: String) {
        val n = number(spec) ?: run { say("I could not find a number for $spec."); return }
        val act = if (hasPerm(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        go(Intent(act, Uri.parse("tel:" + Uri.encode(n)))); say("Calling $spec.")
    }

    private fun sendMessage(kind: String, who: String, msg: String) {
        val n = number(who) ?: run { say("I could not find a number for $who."); return }
        if (kind == "sms" || kind == "text" || kind == "message") {
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", msg))
        } else {
            val pkg = if (kind.contains("business")) "com.whatsapp.w4b" else "com.whatsapp"
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${intl(n)}?text=" + Uri.encode(msg))).setPackage(pkg))
        }
        say("Message ready for $who. Tap send.")
    }

    private fun ask(q: String): String {
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) return "Please open the MIRA app and add your Gemini key."
        val model = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        val city = prefs.getString("city", "") ?: ""
        val sys = "You are MIRA, a voice assistant on the user's phone. Reply in one to three short spoken sentences, no markdown or lists. " +
            "Use Google Search for anything current such as weather, news, people, prices or scores. Current time: ${Date()}." +
            if (city.isNotBlank()) " The user lives in $city; use it when no place is given." else ""
        history.put(turn("user", q))
        while (history.length() > 12) { history.remove(0); history.remove(0) }
        return try {
            val out = try { gemini(key, model, sys, true) } catch (e: Exception) {
                if (Regex("search|tool|ground", RegexOption.IGNORE_CASE).containsMatchIn(e.message ?: "")) gemini(key, model, sys, false) else throw e
            }
            history.put(turn("model", out)); out
        } catch (e: Exception) {
            history.remove(history.length() - 1)
            "Sorry, " + (e.message ?: "something went wrong").take(120)
        }
    }

    private fun turn(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun gemini(key: String, model: String, sys: String, search: Boolean): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", history)
        if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        val j = JSONObject(txt)
        if (code >= 400) throw Exception(j.optJSONObject("error")?.optString("message") ?: "error $code")
        val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "I could not find an answer."
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim().ifEmpty { "I could not find an answer." }
    }

    override fun onDestroy() {
        running = false
        recognizer?.destroy(); tts?.shutdown()
        super.onDestroy()
    }
}
